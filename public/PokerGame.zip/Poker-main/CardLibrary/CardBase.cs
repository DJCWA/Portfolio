﻿namespace CardLibrary
{
    public class CardBase
    {

   
    }
}